SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  sleep 1
  ui_print " Bởi : Anhsnguyetj  "
  sleep 1
  ui_print " đợi tí "
  sleep 1
  ui_print " đang bắt đầu cài đặt "
  sleep 2
  ui_print " quá trình cài đặt thành công "
  sleep 5
ui_print " 
 ▀▀█▀▀ █░░▒█ █▀▀▀ █▀▀█ █░▄▀ █▀▀▀█
 ░▒█░░ █▒█▒█ █▀▀▀ █▄▄█ █▀▄░ ▀▀▀▄▄
 ░▒█░░ █▄▀▄█ █▄▄▄ █░▒█ █░▒█ █▄▄▄█"
 ui_print "đã thành công thiết lập tweak"
su -c cmd settings put global window_animation_scale 0.63
su -c cmd settings put global transition_animation_scale 0.63
su -c cmd settings put global animator_duration_scale 0.63
su -c cmd settings put secure long_press_timeout 180
su -c cmd settings put global wifi_scan_always_enabled 0
su -c cmd settings put secure multi_press_timeout 180
su -c cmd settings put system sound_effects_enable 0
su -c cmd settings put global dropbox_max_files 1
su -c settings put system miui_recents_show_recommend 0
  sleep 1
  ui_print " NGÀY BẠN CÀI MODULE NÀY: $(date +"%d-%m-%Y %r" )"
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

on_install() {
 unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}