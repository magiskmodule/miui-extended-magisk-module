#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

#app thừa
su -c pm uninstall --user 0 com.miui.systemAdSolution
su -c pm uninstall --user 0 disable com.miui.analytics
su -c pm uninstall --user 0 disable com.android.stk
su -c pm uninstall --user 0 com.miui.bugreport
su -c pm uninstall --user 0 com.android.printspooler
su -c pm uninstall --user 0 com.google.android.apps.restore
su -c pm uninstall --user 0 com.android.wallpaper.livepicker
su -c pm uninstall --user 0 com.google.android.partnersetup
su -c pm uninstall --user 0 com.google.android.feedback
su -c pm uninstall --user 0 com.google.android.pixel.setupwizard
su -c pm uninstall --user 0 com.google.android.printservice.recommendation
su -c pm uninstall --user 0 com.android.bookmarkprovider
su -c pm uninstall --user 0 com.android.emergency
su -c pm uninstall --user 0 com.android.cellbroadcastservice
su -c pm uninstall --user 0 com.android.cellbroadcastreceiver
su -c pm uninstall --user 0 com.google.android.onetimeinitializer
su -c pm uninstall --user 0 com.google.android.setupwizard
su -c pm uninstall --user 0 com.android.egg
su -c pm uninstall --user 0 com.google.android.tag
su -c pm uninstall --user 0 com.tencent.soter.soterserver
su -c pm uninstall --user 0 com.android.bips
su -c pm uninstall --user 0 com.miui.vsimcore
su -c pm uninstall --user 0 com.miui.compass
su -c pm uninstall --user 0 com.miui.fm
su -c pm uninstall --user 0 com.miui.cit
su -c pm uninstall --user 0 com.android.traceur
su -c pm disable com.google.android.gms/.chimera.GmsIntentOperationService
su -c pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
su -c pm disable com.xiaomi.joyose/.smartop.gamebooster.receiver.BoostRequestReceiver >/dev/null 2>&1
su -c pm disable com.xiaomi.joyose/.smartop.SmartOpService >/dev/null 2>&1
su -c pm disable com.xiaomi.joyose.sysbase.MetokClService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.cloudcontrol.CloudControlSyncService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.statistics.services.GraphicDumpService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.statistics.services.AtraceDumpService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.SysoptService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.MiuiPerfService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.server.ExecutorService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.mqsas.jobs.EventUploadService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.mqsas.jobs.FileUploadService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.mqsas.jobs.HeartBeatUploadService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.mqsas.providers.MQSProvider >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.provider.PerfTurboProvider >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.system.am.SysoptjobService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.system.am.MemCompactService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.statistics.services.FreeFragDumpService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.statistics.services.DefragService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.statistics.services.MeminfoService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.statistics.services.IonService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.statistics.services.GcBoosterService >/dev/null 2>&1
su -c pm disable com.miui.daemon/.mqsas.OmniTestReceiver >/dev/null 2>&1
su -c pm disable com.miui.daemon/.performance.MiuiPerfService >/dev/null 2>&1
#killall -9 com.miui.daemon >/dev/null 2>&1

sleep 40

#Sử dụng sâu để tiết kiệm điện hơn trong thời gian nhàn rỗi
echo "Y" > /sys/module/workqueue/parameters/power_efficient
echo "1" > /sys/devices/system/cpu/sched_mc_power_savings
echo "deep" > /sys/power/mem_sleep
su -c "stop logd"
su -c "stop tcpdump"
su -c "stop cnss_diag"
su -c "stop statsd"
su -c "stop traced"

# Tắt Fsync
echo "N" > /sys/module/sync/parameters/fsync_enabled

# Tắt ram dump
for parameters in /sys/module/subsystem_restart/parameters; do
    write $parameters/enable_ramdumps 0
    write $parameters/enable_mini_ramdumps 0
done

# Đặt CPUSet
for cpu_set in /dev/cpuset; do
    write $cpu_set/cpus 0-7
    write $cpu_set/effective_cpus 0-7
    write $cpu_set/background/cpus 0-2
    write $cpu_set/background/effective_cpus 0-2
    write $cpu_set/system-background/cpus 0-3
    write $cpu_set/system-background/effective_cpus 0-3
    write $cpu_set/foreground/cpus 0-1,6-7
    write $cpu_set/foreground/effective_cpus 0-1,6-7
    write $cpu_set/foreground/boost/cpus 5-7
    write $cpu_set/top-app/cpus 0-7
    write $cpu_set/top-app/effective_cpus 0-7
    write $cpu_set/restricted/cpus 0-3
    write $cpu_set/restricted/effective_cpus 0-3
    write $cpu_set/camera-daemon/cpus 0-4
    write $cpu_set/camera-daemon/effective_cpus 0-4
    write $cpu_set/camera-daemon-dedicated/cpus 0-4
    write $cpu_set/camera-daemon-dedicated/effective_cpus 0-4
    write $cpu_set/audio-app/cpus 0-2
done

animation_full() {
# Kiểm tra có đang chạy MIUI không
    [[ "$(getprop ro.miui.ui.version.name)" ]] && miui=true

    nr_cores=$(cat /sys/devices/system/cpu/possible | awk -F "-" '{print $2}')
    nr_cores=$(nr_cores + 1)

    [[ "$nr_cores" -eq "0" ]] && nr_cores=1

    [[ "$miui" == "true" ]] && [[ "$nr_cores" == "8" ]] && {
    resetprop persist.sys.miui.sf_cores "4-7"
    resetprop persist.sys.miui_animator_sched.bigcores "4-7"
    }

    [[ "$miui" == "true" ]] && [[ "$nr_cores" == "6" ]] && {
    resetprop persist.sys.miui.sf_cores "0-5"
    resetprop persist.sys.miui_animator_sched.bigcores "2-5"
    }

    [[ "$miui" == "true" ]] && [[ "$nr_cores" == "4" ]] && {
    resetprop persist.sys.miui.sf_cores "0-3"
    resetprop persist.sys.miui_animator_sched.bigcores "0-3"
    }

sleep 20

# Apply settings for miui
animation_full

# Tăng lịch vào launcher
pid=`pgrep -f com.android.commands.input.Input`
chrt -a -r -p 99 $pid
pid=`pgrep -f com.miui.home`
chrt -a -r -p 99 $pid

#cre
su -lp 2000 -c "cmd notification post -S bigtext -t 'Hệ thống Module' 'Tag' 'Chúc mừng máy bạn đã được tối ưu!!'"

exit 0